package com.example.demoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemooApplicationTests {

	@Test
	void contextLoads() {
	}

}
