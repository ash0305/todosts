package com.example.demoo.models;

public class tODO {

	private int id;
	
	private String content;

	public tODO(int id, String content) {
//		super();
		this.id = id;
		this.content = content;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

//	public tODO(int id) {
//		this.id = id;
//	}
	
	

}
