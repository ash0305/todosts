package com.example.demoo.controllers;
import com.example.demoo.models.tODO;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoo.services.TodoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/todos")
public class TodoController {
	
	@Autowired
	private TodoService todoService;
	private List<tODO> todoList = new ArrayList<>();
	
	//create todo
	
	@PostMapping
	public ResponseEntity<tODO> createTodo(@RequestBody tODO todo) {
        if (todo.getContent() == null || todo.getContent().isEmpty()) {
            return ResponseEntity.badRequest().body(null); // Validation: Title is required
        }
        todoList.add(todo);
        return ResponseEntity.status(HttpStatus.CREATED).body(todo);
    }
	
	
	
	
	//get all todo
	@GetMapping
	public ResponseEntity<List<tODO>> getAll(){
		return ResponseEntity.ok(todoList);
	}
}










