package com.example.demoo.services;

import com.example.demoo.models.*;

import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;

@Service
public class TodoService {
	private List<tODO> list=new ArrayList<>();
	
	public tODO create(tODO todo) {
		list.add(todo);
		return todo;
		
	}
	
		public List<tODO> getList(){
				
				return list;
				
			}
	

}
